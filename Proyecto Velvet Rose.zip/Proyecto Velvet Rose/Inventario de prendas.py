import sqlite3
import os

def crear_base_datos():
    # Crear carpeta 'data' si no existe
    os.makedirs("data", exist_ok=True)

    # Conexión a la base de datos SQLite
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()

    # Crear tabla de categorías
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        );
    """)

    # Crear tabla de proveedores
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS proveedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            contacto TEXT
        );
    """)

    # Crear tabla de productos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            talla TEXT,
            color TEXT,
            stock INTEGER DEFAULT 0,
            categoria_id INTEGER,
            proveedor_id INTEGER,
            FOREIGN KEY (categoria_id) REFERENCES categorias(id),
            FOREIGN KEY (proveedor_id) REFERENCES proveedores(id)
        );
    """)

    # Crear tabla de ventas
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            producto_id INTEGER,
            cantidad INTEGER,
            fecha TEXT,
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        );
    """)

    # Insertar categorías
    categorias = ["Ropa", "Pantalones", "Vestidos", "Calzado", "Abrigos"]
    for cat in categorias:
        cursor.execute("INSERT OR IGNORE INTO categorias (nombre) VALUES (?);", (cat,))

    # Insertar proveedor genérico
    cursor.execute("INSERT OR IGNORE INTO proveedores (nombre, contacto) VALUES (?, ?);", 
                   ("Proveedor Genérico", "proveedor@email.com"))

    # Obtener ID del proveedor
    cursor.execute("SELECT id FROM proveedores WHERE nombre = ?;", ("Proveedor Genérico",))
    proveedor_id = cursor.fetchone()[0]

    # Obtener IDs de categorías
    cat_ids = {}
    for cat in categorias:
        cursor.execute("SELECT id FROM categorias WHERE nombre = ?;", (cat,))
        cat_ids[cat] = cursor.fetchone()[0]

    # Insertar productos de ejemplo
    productos = [
        ("Camiseta básica", "S", "Blanco", 12, "Ropa"),
        ("Camiseta básica", "M", "Blanco", 4, "Ropa"),
        ("Jeans corte recto", "32", "Azul oscuro", 6, "Pantalones"),
        ("Vestido floreado", "L", "Rojo", 2, "Vestidos"),
        ("Zapatos deportivos", "38", "Negro", 10, "Calzado"),
        ("Chaqueta impermeable", "L", "Gris", 3, "Abrigos")
    ]

    for nombre, talla, color, stock, categoria in productos:
        cursor.execute("""
            INSERT INTO productos (nombre, talla, color, stock, categoria_id, proveedor_id)
            VALUES (?, ?, ?, ?, ?, ?);
        """, (nombre, talla, color, stock, cat_ids[categoria], proveedor_id))

    # Guardar cambios y cerrar conexión
    conn.commit()
    conn.close()
    print("✅ Base de datos creada correctamente")

# Ejecutar
crear_base_datos()




