import sqlite3

conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

#Columna precio
try:
    cursor.execute("ALTER TABLE productos ADD COLUMN precio REAL DEFAULT 0")
    print("✅ Columna 'precio' añadida correctamente.")
except sqlite3.OperationalError:
    print("⚠️ La columna 'precio' ya existe.")
# Añadir columna total
try:
    cursor.execute("ALTER TABLE ventas ADD COLUMN total REAL DEFAULT 0")
    print("✅ Columna 'total' añadida correctamente.")
except sqlite3.OperationalError:
    print("⚠️ La columna 'total' ya existe.")

conn.commit()
conn.close()
