from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Obtener productos del inventario
def obtener_productos():
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT productos.id, productos.nombre, productos.talla, productos.color, productos.stock,
               categorias.nombre, proveedores.nombre
        FROM productos
        JOIN categorias ON productos.categoria_id = categorias.id
        JOIN proveedores ON productos.proveedor_id = proveedores.id
    """)
    datos = cursor.fetchall()
    conn.close()
    return datos

# Ruta principal con búsqueda opcional
@app.route("/")
def lista_productos():
    search_query = request.args.get("search", "").strip()
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()

    if search_query:
        cursor.execute("""
            SELECT productos.id, productos.nombre, productos.talla, productos.color, productos.stock,
                   categorias.nombre, proveedores.nombre
            FROM productos
            JOIN categorias ON productos.categoria_id = categorias.id
            JOIN proveedores ON productos.proveedor_id = proveedores.id
            WHERE productos.nombre LIKE ?
        """, ('%' + search_query + '%',))
    else:
        cursor.execute("""
            SELECT productos.id, productos.nombre, productos.talla, productos.color, productos.stock,
                   categorias.nombre, proveedores.nombre
            FROM productos
            JOIN categorias ON productos.categoria_id = categorias.id
            JOIN proveedores ON productos.proveedor_id = proveedores.id
        """)

    productos = cursor.fetchall()
    conn.close()
    return render_template("productos.html", productos=productos)

# Agregar nuevo producto
@app.route("/agregar", methods=["GET", "POST"])
def agregar_producto():
    if request.method == "POST":
        nombre = request.form["nombre"]
        talla = request.form["talla"]
        color = request.form["color"]
        stock = int(request.form["stock"])
        categoria_id = int(request.form["categoria_id"])
        proveedor_id = int(request.form["proveedor_id"])

        conn = sqlite3.connect("data/inventario.db")
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO productos (nombre, talla, color, stock, categoria_id, proveedor_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (nombre, talla, color, stock, categoria_id, proveedor_id))
        conn.commit()
        conn.close()

        return redirect(url_for("lista_productos"))

    return render_template("agregar.html")

# Editar producto existente
@app.route("/editar/<int:id>", methods=["GET", "POST"])
def editar_producto(id):
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()

    if request.method == "POST":
        nombre = request.form["nombre"]
        talla = request.form["talla"]
        color = request.form["color"]
        stock = int(request.form["stock"])
        categoria_id = int(request.form["categoria_id"])
        proveedor_id = int(request.form["proveedor_id"])

        cursor.execute("""
            UPDATE productos
            SET nombre = ?, talla = ?, color = ?, stock = ?, categoria_id = ?, proveedor_id = ?
            WHERE id = ?
        """, (nombre, talla, color, stock, categoria_id, proveedor_id, id))
        conn.commit()
        conn.close()
        return redirect(url_for("lista_productos"))
    else:
        cursor.execute("SELECT * FROM productos WHERE id = ?", (id,))
        producto = cursor.fetchone()
        conn.close()
        return render_template("editar.html", producto=producto)

# Eliminar producto
@app.route("/eliminar/<int:id>", methods=["POST"])
def eliminar_producto(id):
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM productos WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for("lista_productos"))

# Reporte imprimible
@app.route("/reporte")
def reporte_productos():
    productos = obtener_productos()
    return render_template("reporte.html", productos=productos)
#Vista de lista de proveedores
@app.route("/proveedores")
def lista_proveedores():
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS proveedores (id INTEGER PRIMARY KEY, nombre TEXT)")
    cursor.execute("SELECT * FROM proveedores")
    proveedores = cursor.fetchall()
    conn.close()
    return render_template("proveedores.html", proveedores=proveedores)
#Agregar proveedores 
@app.route("/proveedores/agregar", methods=["POST"])
def agregar_proveedor():
    nombre = request.form["nombre"]
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO proveedores (nombre) VALUES (?)", (nombre,))
    conn.commit()
    conn.close()
    return redirect(url_for("lista_proveedores"))
 #Gestionar proveedores 
@app.route("/proveedores")
def gestionar_proveedores():
    proveedores = obtener_proveedores()
    return render_template("proveedores.html", proveedores=proveedores)
#Registrar ventas
@app.route("/registrar_venta", methods=["POST"])
def registrar_venta():
    producto_id = int(request.form["producto_id"])
    cantidad = int(request.form["cantidad"])
    
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()

    cursor.execute("SELECT precio FROM productos WHERE id = ?", (producto_id,))
    resultado = cursor.fetchone()
    precio_unitario = resultado[0] if resultado else 0
    total = cantidad * precio_unitario

    fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
        INSERT INTO ventas (producto_id, cantidad, fecha, total)
        VALUES (?, ?, ?, ?)
    """, (producto_id, cantidad, fecha_actual, total))

    conn.commit()
    conn.close()
    return redirect(url_for("lista_productos"))
#Reporte de ventas
@app.route("/ventas")
def reporte_ventas():
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ventas.cantidad, productos.nombre,
                strftime('%Y-%m-%d', ventas.fecha), ventas.total
        FROM ventas
        JOIN productos ON ventas.producto_id = productos.id
    """)
    ventas = cursor.fetchall()
    conn.close()
    return render_template("ventas.html", ventas=ventas)
#Envio del formulario 
@app.route("/ventas/registrar", methods=["GET"])
def mostrar_formulario_venta():
    conn = sqlite3.connect("data/inventario.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, nombre, talla FROM productos
    """)
    productos = cursor.fetchall()
    cursor.execute("""
        SELECT ventas.id, productos.nombre, ventas.cantidad, ventas.fecha 
        FROM ventas 
        JOIN productos ON ventas.producto_id = productos.id
        ORDER BY ventas.fecha DESC
        LIMIT 5
    """)
    ventas = cursor.fetchall()
    conn.close()
    return render_template("registrar_ventas.html", productos=productos, ventas=ventas)


if __name__ == "__main__":
    app.run(debug=True)


       
   
