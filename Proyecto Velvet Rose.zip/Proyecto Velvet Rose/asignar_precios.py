import sqlite3

conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

# Asignar precios específicos a productos por nombre
productos_precios = [
    ("Camiseta básica", 3500),
    ("Jeans corte recto", 15000),
    ("Vestido floreado", 12000)
]

for nombre, precio in productos_precios:
    cursor.execute("UPDATE productos SET precio = ? WHERE nombre = ?", (precio, nombre))
    #Agregar precios faltantes 
    precios_faltantes = [
    ("Zapatos deportivos", 8000),
    ("Chaqueta impermeable", 10000)
]

for nombre, precio in precios_faltantes:
    cursor.execute("UPDATE productos SET precio = ? WHERE nombre = ?", (precio, nombre))

conn.commit()
print("✅ Precios asignados correctamente.")
conn.close()
