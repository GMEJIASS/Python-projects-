import sqlite3

conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

# Inserta una venta: producto_id=1, cantidad=2, fecha actual
cursor.execute("""
    INSERT INTO ventas (producto_id, cantidad, fecha)
    VALUES (?, ?, DATE('now'))
""", (1, 2))

conn.commit()
conn.close()

print("✅ Venta de prueba insertada.")
