import sqlite3

# Conectar a la base de datos inventario.db
conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

# Crear la tabla ventas si no existe
cursor.execute("""
CREATE TABLE IF NOT EXISTS ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER,
    cantidad INTEGER,
    fecha TEXT,
    total REAL,
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);
""")

conn.commit()
conn.close()

print("✅ Tabla 'ventas' creada correctamente.")
