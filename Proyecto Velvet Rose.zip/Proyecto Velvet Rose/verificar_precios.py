import sqlite3

conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

cursor.execute("SELECT nombre, precio FROM productos")
productos = cursor.fetchall()

for producto in productos:
    print(f"Producto: {producto[0]}, Precio: {producto[1]}")

conn.close()
