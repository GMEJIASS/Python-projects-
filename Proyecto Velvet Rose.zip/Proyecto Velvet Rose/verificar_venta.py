import sqlite3

conn = sqlite3.connect("data/inventario.db")
cursor = conn.cursor()

cursor.execute("SELECT * FROM ventas")
ventas = cursor.fetchall()

for venta in ventas:
    print(venta)

conn.close()
